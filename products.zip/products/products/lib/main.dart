import 'package:fab_circular_menu_plus/fab_circular_menu_plus.dart';
import 'package:flutter/material.dart';

import 'cart_page.dart';
import 'home_page.dart';
import 'my_fav.dart';
import 'notification_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'E-Commerce App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: false),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  // Pages list including FavPage
  final List<Widget> _pages = const [
    HomePage(),
    FavPage(),
    NotificationPage(),
    CartPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: _pages),
      floatingActionButton: FabCircularMenuPlus(
        ringColor: Colors.blue.shade100,
        ringDiameter: 300,
        fabSize: 60,
        ringWidth: 60,
        fabMargin: const EdgeInsets.all(16),
        fabOpenColor: Colors.red.shade200,
        fabColor: Colors.blue,
        fabIconBorder: const CircleBorder(),
        children: [
          IconButton(
            onPressed: () {
              setState(() {
                _selectedIndex = 0; // Home Page
              });
            },
            icon: const Icon(Icons.home, color: Colors.blue),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                _selectedIndex = 1; // Favorites Page
              });
            },
            icon: const Icon(Icons.favorite, color: Colors.red),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                _selectedIndex = 2; // Notification Page
              });
            },
            icon: const Icon(Icons.notifications, color: Colors.orange),
          ),
          IconButton(
            onPressed: () {
              setState(() {
                _selectedIndex = 3; // Cart Page
              });
            },
            icon: const Icon(Icons.shopping_cart, color: Colors.pink),
          ),
        ],
      ),
    );
  }
}
