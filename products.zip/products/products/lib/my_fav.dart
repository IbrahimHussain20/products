import 'package:fab_circular_menu_plus/fab_circular_menu_plus.dart';
import 'package:flutter/material.dart';
import 'package:products/cart_page.dart';
import 'package:products/home_page.dart';
import 'package:products/notification_page.dart';

class FavPage extends StatelessWidget {
  const FavPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorites'),
        centerTitle: true,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: const Center(
        child: Text(
          'Favorites Page',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FabCircularMenuPlus(
        ringColor: Colors.blue.shade100,
        ringDiameter: 300,
        fabSize: 60,
        ringWidth: 60,
        fabMargin: const EdgeInsets.all(16),
        fabOpenColor: Colors.red.shade200,
        fabColor: Colors.blue,
        fabIconBorder: const CircleBorder(),
        children: [
          IconButton(
            onPressed: () => _gotoPage(context, const HomePage()),
            icon: const Icon(Icons.home, color: Colors.blue),
          ),
          IconButton(
            onPressed: () => _gotoPage(context, const FavPage()),
            icon: const Icon(Icons.favorite, color: Colors.red),
          ),
          IconButton(
            onPressed: () => _gotoPage(context, const CartPage()),
            icon: const Icon(Icons.shopping_cart, color: Colors.pink),
          ),
          IconButton(
            onPressed: () => _gotoPage(context, const NotificationPage()),
            icon: const Icon(Icons.notifications, color: Colors.blue),
          ),
        ],
      ),
    );
  }

  void _gotoPage(BuildContext context, Widget page) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }
}
