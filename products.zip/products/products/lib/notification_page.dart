import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({super.key});

  final List<String> notifications = const [
    'You have one new notification from Sunny.',
    'You have one new notification from Raman.',
    'You have one new notification from Sunny.',
    'You have one new notification from Sunny.',
    'You have one new notification from Anchal.',
    'You have one new notification from Anchal.',
    'You have one new notification from Pooja.',
    'You have one new notification from Anchal.',
    'You have one new notification from Anchal.',
    'You have one new notification from Pooja.',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        centerTitle: true,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView.separated(
        itemCount: notifications.length,
        separatorBuilder: (context, index) =>
            const Divider(height: 1, thickness: 1, color: Colors.grey),
        itemBuilder: (context, index) {
          return ListTile(
            leading: const Icon(Icons.notifications, color: Colors.blue),
            title: Text(
              notifications[index],
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            ),
          );
        },
      ),
    );
  }
}
